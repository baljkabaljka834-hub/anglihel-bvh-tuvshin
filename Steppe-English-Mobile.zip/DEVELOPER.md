# Steppe English Mobile 1.1

A prebuilt, dependency-free PWA conversion of the HTML explicitly supplied in
this conversation. No account secrets, progress records or generated QA backup
files are included. The prior standalone HTML remains unchanged.

## Publish
Upload the CONTENTS of this folder, or the supplied flat ZIP, to a static HTTPS
host. `index.html` must be at the site root. No build command or npm packages
are required. Cloudflare Pages Direct Upload supports this ZIP. `_headers`
provides MIME/security/cache controls on compatible hosts; `vercel.json` is a
configuration for Vercel hosting. Neither file by itself deploys the app.

A localhost server is suitable for development on the same computer only.
Plain HTTP on a LAN address is not an equivalent mobile installation test.

## Architecture
- Original HTML/CSS/course/logic retained, with explicit mobile enhancements.
- Course content and all 1,098 MP3 data clips stay inline in index.html.
- Web manifest uses a relative scope and start URL, standalone display, 192/512
  PNG icons, an Android maskable icon and an Apple 180px touch icon.
- CSP allows this origin for the worker, manifest and static files. No analytics
  script, API key, login server or database is part of this app.
- `#pwa-script` in index.html controls platform-specific instructions, optional
  browser installation prompt, actual cache readiness, updates and native-file
  sharing with a normal download fallback. User input remains escaped.
- Service-worker install precaches six required assets, verifies success, and
  does not activate an incomplete cache. Cache names are scope-isolated.
- Navigation to the scoped root or index.html (including start URL queries)
  returns the complete cached page. Other URLs are not rewritten to HTML.
- Upgrades wait for an explicit user action, then save progress before reload.
  Unrelated host/application caches are never deleted.
- Progress keeps the original steppe-english-v1 schema/key. It is device-local,
  not cloud-synced. New origin requires manual JSON export/import.
- Portable HTML export strips PWA-only links/script/banner so that the exported
  archive still contains all learning content without external files. It is not
  an iOS installation method.

## Change a release
Edit the inline application/mobile code and static files, then change the
RELEASE constant consistently in `index.html` and `sw.js`. Upload the complete
folder atomically. Avoid using mutable private progress files as deployment
sources. Host-provider deployment configuration may evolve; check its current
instructions before publishing.

## Manual acceptance checklist after publication
1. Open the actual HTTPS URL in Chrome/Edge on Android and Safari on iPhone.
2. Confirm the app, icons, manifest and worker return correct MIME types.
3. Wait until the app reports offline-ready; install via browser/Share menu.
4. Open the installed app online and check readiness again.
5. Complete a lesson, play audio, export a JSON backup, close the app.
6. Enable airplane mode and open it again from the home-screen icon. Check
   lesson content, audio and persistence. Do not treat an open tab alone as proof.
7. Import the JSON on a second device, checking the explicit replace prompt.
8. Grant microphone permission only on request; confirm stop/navigation/background
   cleanup and saved recording playback on both platforms.
9. Deploy a changed release; confirm manual update and retained progress.

## Limitations
No physical devices, Safari renderer, real installation, native share sheet or
microphone capture were certified here. Chromium's administrator policy blocked
localhost navigation. No attempt was made to bypass that restriction. Functional
UI QA used set_content and an explicit localStorage mock. Service-worker QA used
Node with simulated Cache API, fetch and lifecycle events, not a live browser
worker. See TEST-REPORT.txt.
