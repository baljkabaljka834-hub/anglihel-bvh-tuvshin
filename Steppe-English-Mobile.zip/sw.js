/* Dedicated, scope-isolated offline cache. No third-party requests. */
'use strict';
const RELEASE='1.1.0-fa54e40cd7';
const ROOT=new URL('./',self.location.href);
const PREFIX='steppe-mobile-'+encodeURIComponent(ROOT.pathname)+'-';
const CACHE=PREFIX+RELEASE;
const ASSETS=['index.html','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png'];
const absolute=p=>new URL(p,ROOT).href;
async function notify(message){const clients=await self.clients.matchAll({type:'window',includeUncontrolled:true});for(const c of clients){if(c.url.startsWith(ROOT.href))c.postMessage(message);}}
let filling=null;
function fillCache(force=false){
 if(filling)return filling;
 filling=(async()=>{
  const cache=await caches.open(CACHE);let done=0;
  for(const path of ASSETS){
   const url=absolute(path);
   if(!force&&await cache.match(url)){done++;await notify({type:'STEPPE_PROGRESS',done,total:ASSETS.length});continue;}
   const response=await fetch(new Request(url,{cache:'reload',credentials:'same-origin'}));
   if(!response.ok||response.type==='opaque')throw new Error('Офлайн файл татагдсангүй: '+path);
   // Reject HTML error/SPA responses masquerading as JSON, icons or the application.
   const mime=response.headers.get('content-type')||'';
   if(path.endsWith('.png')&&!mime.includes('image/png'))throw new Error('Буруу зураг: '+path);
   if(path.endsWith('.webmanifest')&&!/json|manifest/.test(mime))throw new Error('Manifest MIME буруу.');
   if(path==='index.html'&&!mime.includes('text/html'))throw new Error('Аппын HTML MIME буруу.');
   await cache.put(url,response);done++;await notify({type:'STEPPE_PROGRESS',done,total:ASSETS.length});
  }
  await notify({type:'STEPPE_READY',release:RELEASE});
 })().finally(()=>{filling=null;});return filling;
}
self.addEventListener('install',event=>{
 event.waitUntil((async()=>{
  try{await fillCache();if(!self.registration.active)await self.skipWaiting();}
  catch(error){await caches.delete(CACHE);await notify({type:'STEPPE_FAILED',message:String(error)});throw error;}
 })());
});
self.addEventListener('activate',event=>{
 event.waitUntil((async()=>{
  const names=await caches.keys();await Promise.all(names.filter(name=>name.startsWith(PREFIX)&&name!==CACHE).map(name=>caches.delete(name)));
  await self.clients.claim();await notify({type:'STEPPE_READY',release:RELEASE});
 })());
});
self.addEventListener('message',event=>{
 const type=event.data?.type;
 if(type==='STEPPE_SKIP_WAITING'){event.waitUntil(self.skipWaiting());return;}
 if(type==='STEPPE_STATUS')event.waitUntil((async()=>{
  const cache=await caches.open(CACHE);const present=await Promise.all(ASSETS.map(path=>cache.match(absolute(path)).then(Boolean)));
  const result={type:'STEPPE_STATUS',ready:present.every(Boolean),done:present.filter(Boolean).length,total:ASSETS.length,release:RELEASE};
  if(event.ports[0])event.ports[0].postMessage(result);else event.source?.postMessage(result);
 })());
 if(type==='STEPPE_REPAIR')event.waitUntil(fillCache().catch(error=>notify({type:'STEPPE_FAILED',message:String(error)})));
});
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==ROOT.origin||!url.pathname.startsWith(ROOT.pathname))return;
 const path=url.pathname.slice(ROOT.pathname.length);
 if(request.mode==='navigate'&&(path===''||path==='index.html')){
  event.respondWith((async()=>{
   const cache=await caches.open(CACHE);const cached=await cache.match(absolute('index.html'));
   if(cached)return cached;
   try{return await fetch(request);}catch(_){return new Response('<!doctype html><html lang="mn"><meta charset="utf-8"><meta name="viewport" content="width=device-width"><title>Steppe English</title><h1>Интернэтэд нэг удаа холбоорой.</h1><p>Офлайн таталт бүрэн дуусаагүй эсвэл хадгалалт арилсан байна. Интернэттэй үед аппыг дахин нээгээд «Офлайн бэлэн» төлөвийг шалгана уу.</p></html>',{status:503,headers:{'Content-Type':'text/html;charset=utf-8'}});}
  })());return;
 }
 if(ASSETS.includes(path))event.respondWith((async()=>{
  const cache=await caches.open(CACHE);const cached=await cache.match(absolute(path));return cached||fetch(request);
 })());
});
